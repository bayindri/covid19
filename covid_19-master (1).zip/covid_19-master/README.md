# COVID_19

Git Repo for COVID_19 analysis for Member POD


Run
```
spark2-submit --master yarn --deploy-mode client --jars /usr/lib/nz/nz-connector.jar analysis/main.py abaner02
```

1 - download the days Mass GOV COVID report from ```https://www.mass.gov/info-details/covid-19-cases-quarantine-and-monitoring#testing-at-the-massachusetts-state-public-health-laboratory-```
and upload to ```input``` folder<br>
2 - make sure file name is consistent with other ```*.docx```  files in folder. Dont put any other kind of ```*.docx``` file in this folder except the mass_gov daily case reports. <br>
3 - then run above command with your lanid at the end<br>
4 - After job finishes copy ```output``` folder to ```\\bos0105dc01\EDS-Dfs\Enterprise_Analytics\Analytics Pods\Member Analytics Pod\COVID19\Wave5_Predictive Heat Map and Listening Post\4_Data\Data_ADT\``` using filezilla.
The file will be picked up for Tableau dashboard from here.
